
import java.util.Scanner;

public class mile_kilometer {
	public static void main (String[] args) {
		
		Scanner input = new Scanner (System.in);
		double mile;
		double kilometer;
		
		
		System.out.print("������ �Է��Ͻÿ�: " );
		mile = input.nextDouble();
		
		kilometer=mile*1.609;
		
		System.out.print(mile + "������ " + kilometer + "ų�α׷��Դϴ�.");
		kilometer = input.nextDouble();
		
	
	}

}


import java.util.Scanner;

public class cm_inch {
	public static void main(String args[]) {

		Scanner input = new Scanner(System.in);
		double cm;
		double inch;
		double feet;

		System.out.print("Ű�� �Է��Ͻÿ�: ");
		cm = input.nextDouble();
		
		feet = cm/(12*2.54);
		int f = (int) Math.floor(feet);
		inch = 12.0*(feet-f);

		System.out.print(cm + "cm�� " + f + "��Ʈ " + inch + "��ġ�Դϴ�.");

	}

}

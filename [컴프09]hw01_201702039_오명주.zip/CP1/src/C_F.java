
import java.util.Scanner;

public class C_F {
	public static void main(String[] args) {
		
		Scanner input = new Scanner (System.in);
		double C;
		double F;
		
		System.out.print("ȭ���� �Է��Ͻÿ�: " );
		F = input.nextDouble();
		
		C=5.0/9.0*(F-32);
		
		System.out.print(F + "'F�� " + C + "'C�Դϴ�.");
		C = input.nextDouble();
		
		
		
		
	}
}

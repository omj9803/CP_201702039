
import java.util.Scanner;

public class hw2 {
	public static void main (String [] args) {
		Scanner input = new Scanner(System.in);
		
		double a;
		double b;
		
		System.out.print("���� �Է��Ͻÿ�: ");
		a = input.nextInt();
		
		b = 3.3058*a;
		
		System.out.print("�����ʹ� " + b + "�Դϴ�.");
		
		
	}

}

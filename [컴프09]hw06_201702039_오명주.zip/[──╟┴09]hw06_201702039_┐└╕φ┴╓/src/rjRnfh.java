import java.util.Scanner;

public class rjRnfh {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		String str;

		System.out.print("���ڿ��� �Է��Ͻÿ�: ");
		str = input.nextLine();

		System.out.println(reverseString(str));

	}

	public static String reverseString(String str) {
		return (new StringBuffer(str)).reverse().toString();
	}

}

public class id {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		login a = new login();
		
		a.hi();
		a.compare();
		
		
		
	}

}


class Employee {
	private String name;
	private String number;
	private int money;
	
	public String getName() {return name;}
	public void setName(String na) {name = na;}
	public String getNumber() {return number;}
	public void setNumber(String nu) {number = nu;}
	public int getMoney() {return money;}
	public void setMoney(int m) {money = m;}
	

}

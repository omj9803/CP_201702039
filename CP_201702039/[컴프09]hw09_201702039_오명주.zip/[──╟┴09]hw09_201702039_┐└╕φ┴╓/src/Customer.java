
class Customer extends Person {
	int code;
	int mileage;

	public void setCode(int c) {
		code = c;
	}

	public int getCode() {
		return code;
	}

	public void setMileage(int m) {
		mileage = m;
	}

	public int getMileage() {
		return mileage;
	}

}

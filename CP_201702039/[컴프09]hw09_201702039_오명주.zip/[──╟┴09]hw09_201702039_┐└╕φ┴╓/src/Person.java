
class Person {
	String name;
	String address;
	String number;

	public void setName(String na) {
		name = na;
	}

	public String getName() {
		return name;
	}

	public void setAddress(String a) {
		address = a;
	}

	public String getAddress() {
		return address;
	}

	public void setNumber(String nu) {
		number = nu;
	}

	public String getNumber() {
		return number;
	}

}

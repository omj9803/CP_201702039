class Student {
	String name;
	int code;
	String major;
	int grade;
	int credit;
	
	public void setName(String na) {
		name = na;
	}

	public String getName() {
		return name;
	}
	public void setCode(int co) {
		code = co;
	}

	public int getCode() {
		return code;
	}
	public void setMajor(String m) {
		major = m;
	}

	public String getMajor() {
		return major;
	}
	public void setGrade(int g) {
		grade = g;
	}

	public int getGrade() {
		return grade;
	}
	public void setCredit(int cr) {
		credit = cr;
	}

	public int getCredit() {
		return credit;
	}

}

class College extends Student {
	String type;
	String scholarship;

	public void setType(String t) {
		type = t;
	}

	public String getType() {
		return type;
	}

	public void setScholarship(String s) {
		scholarship = s;
	}

	public String getScholarship() {
		return scholarship;
	}

}

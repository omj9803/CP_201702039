class Studentt extends Student {
	String group;
	
	public void setGroup(String g) {
		group = g;
	}

	public String getGroup() {
		return group;
	}

}

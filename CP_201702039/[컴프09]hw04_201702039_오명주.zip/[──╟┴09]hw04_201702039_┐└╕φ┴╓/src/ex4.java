
import java.util.Random;

public class ex4 {
	public static void main(String[] args) {
		Random input = new Random();
		int a = (int) (Math.random() * 45) + 1;
		int b = (int) (Math.random() * 45) + 1;
		int c = (int) (Math.random() * 45) + 1;
		int d = (int) (Math.random() * 45) + 1;
		int e = (int) (Math.random() * 45) + 1;
		int f = (int) (Math.random() * 45) + 1;

		System.out.println("<�ζ� ���� ���α׷�>");

		while (a == b) {
			b = (int) (Math.random() * 45) + 1;
		}
		while ((a == c) || (b == c)) {
			c = (int) (Math.random() * 45) + 1;
		}
		while ((a == d) || (b == d) || (c == d)) {
			d = (int) (Math.random() * 45) + 1;
		}
		while ((a == e) || (b == e) || (c == e) || (d == e)) {
			e = (int) (Math.random() * 45) + 1;
		}
		while ((a == f) || (b == f) || (c == f) || (d == f) || (e == f)) {
			f = (int) (Math.random() * 45) + 1;
		}

		System.out.println(a + " " + b + " " + c + " " + d + " " + e + " " + f);

	}

}

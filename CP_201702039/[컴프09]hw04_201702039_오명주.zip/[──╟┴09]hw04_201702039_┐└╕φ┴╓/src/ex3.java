public class ex3 {
	public static void main(String[] args) {
		for (int a = 0; a <= 4; a++) {
			for (int b = 4; b > a; b--) {
				System.out.print(" ");
			}

			for (int c = 0; c < 2 * a + 1; c++) {
				System.out.print("*");
			}
			System.out.println();

		}
		for (int a = 4; a >= 0; a--) {
			for (int b = 5; b > a; b--) {
				System.out.print(" ");
			}

			for (int c = 0; c < 2 * a - 1; c++) {
				System.out.print("*");
			}
			System.out.println();

		}

	}

}

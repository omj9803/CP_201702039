package myeongju;

public class ShapeTest {
	private static Shape arrayOfShapes[];
	public static void main(String args[]) {
		shape();
	}
	public static void shape() {
		arrayOfShapes = new Shape[3];
		arrayOfShapes[0] = new Triangle(2,4);
		arrayOfShapes[1] = new Rectangle(2,4);
		arrayOfShapes[2] = new Circle(2);
		for (int i = 0; i<arrayOfShapes.length; i++) {
			System.out.println("������ ���̴� "+ arrayOfShapes[i].area());
		}
		
	}
	

}

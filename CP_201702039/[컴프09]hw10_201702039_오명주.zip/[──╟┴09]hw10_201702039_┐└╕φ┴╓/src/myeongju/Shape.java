package myeongju;

class Shape {
	protected int width, height;

	public Shape() {

	}

	public Shape(int w, int h) {
		width = w;
		height = h;
	}

	public Shape(int w) {
		width = w;
	}

	public int area() {
		return 0;
	}

}

class Triangle extends Shape {
	public Triangle(int w, int h) {
		super(w, h);
	}

	public int area() {
		return (int) (width * height * 0.5);
		
	}
}

class Rectangle extends Shape {
	public Rectangle(int w, int h) {
		super(w, h);
	}

	public int area() {
		return (width * height);
	}
}

class Circle extends Shape {
	public Circle(int w) {
		super(w);
	}

	public int area() {
		return (int) (width * width * 3.14);
	}
}

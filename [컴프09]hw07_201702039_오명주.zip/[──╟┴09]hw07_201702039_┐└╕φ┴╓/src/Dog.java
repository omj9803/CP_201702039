
public class Dog {
	private String name;
	public static String breed;
	public int age;
	
	public Dog(String n, int a) {
		name = n;
		age = a;
	}
	public String getName1() {
		return name;
	}
	public int getAge1() {
		return age;
	}
	
	public Dog(String n, String b, int a) {
		name = n;
		breed = b;
		age = a;
	}
	public String getName() {
		return name;
	}
	public String getBreed() {
		return breed;
	}
	public int getAge() {
		return age;
	}

}


public class PlaneTest {
	public static void main(String[] args) {
		Plane jin1 = new Plane("Daehan", "x-23", 20);
		Plane jin2 = new Plane("Asiana", "a-50", 400);
		Plane jin3 = new Plane("Peach", 100);
		Plane jin4 = new Plane();
		
		int c = Plane.getPlanes();
		System.out.println("������� �� : "+c);
		
		
	}

}

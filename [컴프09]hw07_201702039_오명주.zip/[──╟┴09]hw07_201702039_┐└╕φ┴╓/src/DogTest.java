
public class DogTest {
	public static void main(String[] args) {
		
		Dog a1 = new Dog("Julia",4);
		Dog a2 = new Dog("Coco","Pomeranian",3);
		System.out.println(a1.getAge());
		System.out.println(a2.getName());
	}

}

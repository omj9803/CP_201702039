
public class Plane {

	private String maker;
	private String model;
	private int people;
	private static int count = 0;

	public Plane(String m1, String m2, int p) {
		maker = m1;
		model = m2;
		people = p;
		count++;

	}

	public Plane(String m1, int p) {
		maker = m1;
		people = p;
		count++;

	}

	public Plane() {
		count++;

	}

	public static int getPlanes() {
		return count;
	}

}
